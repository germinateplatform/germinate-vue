<template>
  <Datasets />
</template>

<script setup lang="ts">
  import Datasets from '@/components/widgets/Datasets.vue'
</script>
