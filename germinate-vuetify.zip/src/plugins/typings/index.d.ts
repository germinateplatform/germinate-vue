declare module 'tiny-emitter/instance'
declare module 'vue3-markdown-it'
declare module 'quill-image-uploader'
