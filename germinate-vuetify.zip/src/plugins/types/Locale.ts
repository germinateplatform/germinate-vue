export interface Locale {
  flag: string
  locale: string
  name: string
}
