import type { ViewTableProjects } from '@/plugins/types/germinate'

export interface ExtendedViewTableProjects extends ViewTableProjects {
  file?: File
}
