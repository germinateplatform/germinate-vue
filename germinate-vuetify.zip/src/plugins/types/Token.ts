export interface Token {
  token: string
  imageToken: string
  lifetime: number
  userType: string
  id: number
  username: string
  createdOn: number
}
