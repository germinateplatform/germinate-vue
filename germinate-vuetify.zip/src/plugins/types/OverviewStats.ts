export type OverviewStats = { [key: string]: number }
