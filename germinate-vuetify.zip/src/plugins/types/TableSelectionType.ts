export enum TableSelectionType {
  single = 'single',
  all = 'all',
}
