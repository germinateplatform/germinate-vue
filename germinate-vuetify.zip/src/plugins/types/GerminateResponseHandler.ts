export type GerminateResponseHandler<T> = (args: T) => void
