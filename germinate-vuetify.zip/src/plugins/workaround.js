// Workaround for Plotly.js
window.global ||= window
