<template>
  <router-view />
</template>

<script lang="ts" setup>
  //
</script>
